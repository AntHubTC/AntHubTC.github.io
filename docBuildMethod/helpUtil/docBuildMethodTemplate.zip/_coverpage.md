![logo](img/doc-logo.svg)

# 文档的组织方式

> 先进的文档组织技术

* 采用docsify来组织文档。
* 采用gitbook来进行组织文档[https://fallengodcoder.github.io](https://fallengodcoder.github.io)
* 文档的发布采用github Pages发布到

[GitHub](https://github.com/FallenGodCoder/)
[Get Started](#quick-start)